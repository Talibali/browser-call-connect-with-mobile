<?php 
error_reporting(E_ALL);
	ini_set('display_errors', TRUE);
	ini_set('display_startup_errors', TRUE);

include "Twilio/autoload.php";
use Twilio\Jwt\ClientToken;

// put your Twilio API credentials here

$accountSid = 'Put here SID';

$authToken  = 'put token';

// put your TwiML Application Sid here

$appSid = 'Put App id';

$capability = new ClientToken($accountSid, $authToken);
$capability->allowClientOutgoing($appSid);
$capability->allowClientIncoming('jenny');
$token = $capability->generateToken();
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Hello Client Monkey 4</title>
    <script type="text/javascript"
      src="http://media.twiliocdn.com/sdk/js/client/releases/1.3.21/twilio.min.js"></script>
   <!-- <script type="text/javascript"
      src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js">
    </script>-->
    <!--<link href="//static0.twilio.com/resources/quickstart/client.css"
      type="text/css" rel="stylesheet" />-->
    <script type="text/javascript">

      Twilio.Device.setup("<?php echo $token; ?>");

      Twilio.Device.ready(function (device) {
        jQuery("#log").text("Ready");
      });

      Twilio.Device.error(function (error) {
        jQuery("#log").text("Error: " + error.message);
      });

      Twilio.Device.connect(function (conn) {
        jQuery("#log").text("Successfully established call");
      });

      Twilio.Device.disconnect(function (conn) {
        jQuery("#log").text("Call ended");
      });

      Twilio.Device.incoming(function (conn) {
        jQuery("#log").text("Incoming connection from " + conn.parameters.From);
        // accept the incoming connection and start two-way audio
        conn.accept();
      });

      function call(contactnumber) {
        // get the phone number to connect the call to
       //document.getElementById("refresh").className="fa fa-refresh fa-spin";
        params = {"PhoneNumber": contactnumber};
        Twilio.Device.connect(params);
         //console.log(params.status);


      }

      function hangup() {
        Twilio.Device.disconnectAll();
      }
    </script>
  </head>
  <body>
    <!--<button class="call" onClick="call();">
      Call
    </button>

    <button class="hangup" onClick="hangup();">
      Hangup
    </button>
        
    <input type="text" id="number" name="number"
      placeholder="Enter a phone number to call" value="+919953832432"/>

    <div id="log">Loading pigeons...</div>
	<a href="#"><div></div></a>-->
  </body>
</html>





